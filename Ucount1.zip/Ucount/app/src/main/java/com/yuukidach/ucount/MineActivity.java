package com.yuukidach.ucount;

import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

public class MineActivity extends BaseActivity {
    private TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mine);
    }

    @Override
    public void next(View view) {
        Intent intent=new Intent(MineActivity.this,MainActivity.class);
        startActivity(intent);
    }

    @Override
    public void pre(View view) {

    }

}
